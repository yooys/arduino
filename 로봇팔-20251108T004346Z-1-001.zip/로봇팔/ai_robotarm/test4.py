import cv2
import mediapipe as mp
import math
import serial
import time

# ====== 시리얼 (없어도 실행됨) ======
ser = None
try:
    ser = serial.Serial('COM10', 9600, timeout=1)  # 포트 번호 환경에 맞게
    time.sleep(2)
    print("✅ Arduino connected")
except Exception as e:
    print("⚠️ Arduino not connected:", e)
    ser = None

# ====== MediaPipe ======
mp_pose = mp.solutions.pose
mp_hands = mp.solutions.hands
mp_draw  = mp.solutions.drawing_utils

pose  = mp_pose.Pose(min_detection_confidence=0.7, min_tracking_confidence=0.7)
hands = mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.7, min_tracking_confidence=0.7)

# ====== 유틸 ======
def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def map_range(x, in_lo, in_hi, out_lo, out_hi):
    if in_hi == in_lo:
        return out_lo
    t = (x - in_lo) / (in_hi - in_lo)
    t = clamp(t, 0.0, 1.0)
    return out_lo + t * (out_hi - out_lo)

def calculate_angle(a, b, c):
    """랜드마크 a-b-c(꼭짓점 b)의 2D 각도(도)를 계산"""
    try:
        a = (a.x, a.y); b = (b.x, b.y); c = (c.x, c.y)
        ba = (a[0]-b[0], a[1]-b[1]); bc = (c[0]-b[0], c[1]-b[1])
        denom = (math.hypot(*ba) * math.hypot(*bc)) + 1e-6
        cosang = max(min((ba[0]*bc[0] + ba[1]*bc[1]) / denom, 1.0), -1.0)
        return int(math.degrees(math.acos(cosang)))
    except:
        return 90

# ====== 스무딩/히스테리시스 (그리퍼/회전) ======
ema_grip = None
ema_rot  = None
ALPHA = 0.35
GRIP_CLOSE_T = 0.22
GRIP_OPEN_T  = 0.28
gripper_state = "OPEN"
gripper_val   = 5

# ====== 손목 비례식 매핑 입력 구간 (이전 로직 유지용) ======
WRIST_RAW_MIN = 30
WRIST_RAW_MAX = 150

# ====== 카메라 ======
cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        continue
    frame = cv2.flip(frame, 1)
    rgb   = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    h, w, _ = frame.shape

    try:
        pose_res  = pose.process(rgb)
        hands_res = hands.process(rgb)
    except Exception as e:
        print("⚠️ Inference error:", e)
        continue

    # ------------------------------------------------
    # 1) 어깨/팔꿈치: 원본(0~180)을 90~120으로 비례식 매핑 (그대로)
    # ------------------------------------------------
    shoulder_angle = 90
    elbow_angle    = 90
    wrist_angle    = 90  # 아래 Hands 단계에서 갱신

    wrist_raw_backup = None  # Hands 미검출 시 Pose wrist 비례 매핑에 사용

    if pose_res.pose_landmarks:
        lm = pose_res.pose_landmarks.landmark
        LSH = lm[mp_pose.PoseLandmark.LEFT_SHOULDER]
        LEL = lm[mp_pose.PoseLandmark.LEFT_ELBOW]
        LWR = lm[mp_pose.PoseLandmark.LEFT_WRIST]
        LHIP= lm[mp_pose.PoseLandmark.LEFT_HIP]
        LTH = lm[mp_pose.PoseLandmark.LEFT_THUMB]

        shoulder_raw = calculate_angle(LHIP, LSH, LEL)
        elbow_raw    = calculate_angle(LSH, LEL, LWR)
        wrist_raw_backup = calculate_angle(LEL, LWR, LTH)

        shoulder_angle = int(round(map_range(shoulder_raw, 0, 180, 90, 120)))
        elbow_angle    = int(round(map_range(elbow_raw,   0, 180, 90, 120)))

        sx, sy = int(LSH.x*w), int(LSH.y*h)
        ex, ey = int(LEL.x*w), int(LEL.y*h)
        for (tx, ty, txt) in [(sx, sy, str(shoulder_angle)),
                              (ex, ey, str(elbow_angle))]:
            (tw, th), baseline = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)
            cv2.rectangle(frame, (tx+8, ty-10-th), (tx+8+tw+6, ty-10+baseline), (0,0,0), -1)
            cv2.putText(frame, txt, (tx+10, ty-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)

        mp_draw.draw_landmarks(frame, pose_res.pose_landmarks, mp_pose.POSE_CONNECTIONS)

    # ------------------------------------------------
    # 2) 손목/그리퍼/회전: 기존 로직 + 화면 표시에선 매핑 화살표 제거
    #    서보 전송은 "손목 원시각(0~30 가정) → 90~120 비례" 로만 변환
    # ------------------------------------------------
    rotation_deg = 90
    rotation_val = None
    wrist_from_hand_deg = None
    wrist_raw_for_servo = None  # ★ 서보 전송용 "원시각" 저장

    if hands_res.multi_hand_landmarks and hands_res.multi_handedness:
        # 오른손 우선 처리
        ordered = []
        for hand_lm, hand_hd in zip(hands_res.multi_hand_landmarks,
                                    hands_res.multi_handedness):
            label = hand_hd.classification[0].label  # "Right" or "Left"
            ordered.append((0 if label == "Right" else 1, hand_lm, label))
        ordered.sort(key=lambda x: x[0])

        for _, hand_lm, label in ordered:
            mp_draw.draw_landmarks(frame, hand_lm, mp_hands.HAND_CONNECTIONS)

            WRIST     = hand_lm.landmark[0]
            TH_T      = hand_lm.landmark[4]
            INDEX_MCP = hand_lm.landmark[5]
            INDEX_TIP = hand_lm.landmark[8]
            MID_MCP   = hand_lm.landmark[9]

            # 핀치 시각화(양손 모두)
            tx, ty = int(TH_T.x*w), int(TH_T.y*h)
            ix, iy = int(INDEX_TIP.x*w), int(INDEX_TIP.y*h)
            cv2.circle(frame, (tx, ty), 7, (0,0,255), -1)
            cv2.circle(frame, (ix, iy), 7, (255,0,0), -1)
            cv2.line(frame, (tx, ty), (ix, iy), (0,255,255), 2)
            pinch = math.dist((TH_T.x, TH_T.y), (INDEX_TIP.x, INDEX_TIP.y))
            cx, cy = (tx+ix)//2, (ty+iy)//2
            cv2.putText(frame, f"dist={pinch:.3f}", (cx, cy-12),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)

            palm_size = math.dist((WRIST.x, WRIST.y), (MID_MCP.x, MID_MCP.y)) + 1e-6
            pinch_norm = pinch / palm_size

            if label == "Right":  # 그리퍼
                ema_grip = pinch_norm if ema_grip is None else (ALPHA*pinch_norm + (1-ALPHA)*ema_grip)
                if gripper_state == "OPEN" and ema_grip < GRIP_CLOSE_T:
                    gripper_state = "CLOSE"
                elif gripper_state == "CLOSE" and ema_grip > GRIP_OPEN_T:
                    gripper_state = "OPEN"
                gripper_val = 175 if gripper_state == "CLOSE" else 5
                cv2.putText(frame, f"Grip={ema_grip:.2f} {gripper_state}", (cx, cy+16),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)
            else:  # Left -> 회전
                ema_rot = pinch_norm if ema_rot is None else (ALPHA*pinch_norm + (1-ALPHA)*ema_rot)
                rotation_val = int(round(map_range(ema_rot, 0.06, 0.45, 5, 175)))
                rotation_val = clamp(rotation_val, 5, 175)
                cv2.putText(frame, f"rot={rotation_val}", (cx, cy+16),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)

            # 손목 원시각(0~30 근처) 계산
            hand_wrist_raw = calculate_angle(INDEX_MCP, WRIST, INDEX_TIP)
            wrist_raw_for_servo = hand_wrist_raw  # ★ 서보 전송용 저장

            # ---- 화면 표시는 '→ 매핑' 없이, 원래 표시 로직 유지/간소화 ----
            # (이전 코드의 wrist_candidate 텍스트는 제거)
            wx, wy = int(WRIST.x*w), int(WRIST.y*h)
            cv2.putText(frame, f"Wrist raw={int(hand_wrist_raw)}", (wx+10, wy-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (50,200,255), 2)

            # 이전 로직 유지: 화면/내부 계산용 wrist_angle (필요 시 유지)
            wrist_candidate_for_display = int(round(map_range(hand_wrist_raw, WRIST_RAW_MIN, WRIST_RAW_MAX, 90, 120)))
            wrist_candidate_for_display = clamp(wrist_candidate_for_display, 90, 120)

            if wrist_from_hand_deg is None or label == "Right":
                wrist_from_hand_deg = wrist_candidate_for_display

        # 왼손에서 회전값이 계산되었으면 반영
        rotation_deg = rotation_val if rotation_val is not None else 90
    else:
        rotation_deg = 90

    # 최종 손목 값 (화면/내부표시용)
    if wrist_from_hand_deg is not None:
        wrist_angle = wrist_from_hand_deg
    else:
        if wrist_raw_backup is not None:
            wrist_angle = int(round(map_range(wrist_raw_backup, WRIST_RAW_MIN, WRIST_RAW_MAX, 90, 120)))
            wrist_angle = clamp(wrist_angle, 90, 120)
            # 서보 전송용 원시값 없으면 백업 원시각 사용
            if wrist_raw_for_servo is None:
                wrist_raw_for_servo = wrist_raw_backup
        else:
            wrist_angle = 90

    # ------------------------------------------------
    # 3) 아두이노 전송
    #    ★ 변화점: 손목 '원시각(0~30)' → 서보 90~120 비례 변환만 적용
    # ------------------------------------------------
    if ser and ser.is_open:
        try:
            # 원시각이 없는 경우 안전 기본값
            if wrist_raw_for_servo is None:
                wrist_raw_for_servo = 0.0

            # 0~30  ->  90~120 (비례 변환 + 클램프)
            wrist_servo = int(round(map_range(wrist_raw_for_servo, 0, 30, 90, 120)))
            wrist_servo = clamp(wrist_servo, 90, 120)

            payload = f"{shoulder_angle},{elbow_angle},{wrist_servo},{rotation_deg},{gripper_val}\n"
            ser.write(payload.encode())
        except Exception as e:
            print("⚠️ Serial write error:", e)

    # ------------------------------------------------
    # 4) HUD
    # ------------------------------------------------
    cv2.putText(frame, f"Shoulder: {shoulder_angle}", (10,30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (50,200,255), 2)
    cv2.putText(frame, f"Elbow: {elbow_angle}", (10,60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (50,200,255), 2)
    cv2.putText(frame, f"Wrist: {wrist_angle}", (10,90),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (50,200,255), 2)
    cv2.putText(frame, f"Rotation: {rotation_deg}", (10,120),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (50,200,255), 2)
    cv2.putText(frame, f"Gripper: {gripper_state} ({gripper_val})", (10,150),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (50,200,255), 2)

    cv2.imshow("Robot Arm Control (Right=Gripper, Left=Rotation)", frame)
    key = cv2.waitKey(1) & 0xFF
    if key in (27, ord('q')):
        break

cap.release()
cv2.destroyAllWindows()
if ser and ser.is_open:
    ser.close()
