import cv2
import mediapipe as mp
import math
import serial
import time

# ====== 시리얼 (없어도 실행됨) ======
ser = None
try:
    ser = serial.Serial('COM3', 9600, timeout=1)  # 포트 번호는 환경에 맞게
    time.sleep(2)
    print("✅ Arduino connected")
except Exception as e:
    print("⚠️ Arduino not connected:", e)
    ser = None

# ====== MediaPipe ======
mp_pose = mp.solutions.pose
mp_hands = mp.solutions.hands
mp_draw  = mp.solutions.drawing_utils

pose  = mp_pose.Pose(min_detection_confidence=0.7, min_tracking_confidence=0.7)
hands = mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.7, min_tracking_confidence=0.7)

# ====== 유틸 ======
def calculate_angle(a, b, c):
    try:
        a = (a.x, a.y); b = (b.x, b.y); c = (c.x, c.y)
        ba = (a[0]-b[0], a[1]-b[1]); bc = (c[0]-b[0], c[1]-b[1])
        denom = (math.hypot(*ba) * math.hypot(*bc)) + 1e-6
        cosang = max(min((ba[0]*bc[0] + ba[1]*bc[1]) / denom, 1.0), -1.0)
        return int(math.degrees(math.acos(cosang)))
    except:
        return 90

def clamp(v, lo, hi): return max(lo, min(hi, v))

def map_range(x, in_lo, in_hi, out_lo, out_hi):
    if in_hi == in_lo: return out_lo
    t = (x - in_lo) / (in_hi - in_lo)
    return out_lo + clamp(t, 0.0, 1.0) * (out_hi - out_lo)

# ====== 스무딩/히스테리시스 상태 ======
ema_grip = None     # 오른손 핀치 정규화 EMA
ema_rot  = None     # 왼손 핀치 정규화 EMA
ALPHA = 0.35        # EMA 계수 (0.2~0.5 권장)

# 히스테리시스 임계 (정규화된 핀치 거리)
GRIP_CLOSE_T = 0.22   # 이보다 작아지면 CLOSE
GRIP_OPEN_T  = 0.28   # 이보다 커지면 OPEN
gripper_state = "OPEN"
gripper_val   = 5

# ====== 카메라 ======
cap = cv2.VideoCapture(0)
# cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # 필요하면 사용

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        continue

    frame = cv2.flip(frame, 1)
    rgb   = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    h, w, _ = frame.shape

    # ---- 인퍼런스 ----
    try:
        pose_res  = pose.process(rgb)
        hands_res = hands.process(rgb)
    except Exception as e:
        print("⚠️ Inference error:", e)
        continue

    # ------------------------------
    # 1) 오른팔 각도: 관절 근처에 "큰 글씨"로
    # ------------------------------
    shoulder_angle = elbow_angle = wrist_angle = 90
    if pose_res.pose_landmarks:
        lm = pose_res.pose_landmarks.landmark
        RSH = lm[mp_pose.PoseLandmark.RIGHT_SHOULDER]
        REL = lm[mp_pose.PoseLandmark.RIGHT_ELBOW]
        RWR = lm[mp_pose.PoseLandmark.RIGHT_WRIST]
        RHIP= lm[mp_pose.PoseLandmark.RIGHT_HIP]
        RTH = lm[mp_pose.PoseLandmark.RIGHT_THUMB]  # 손목 각도 보조용

        shoulder_angle = calculate_angle(RHIP, RSH, REL)
        elbow_angle    = calculate_angle(RSH, REL, RWR)
        wrist_angle    = calculate_angle(REL, RWR, RTH)

        # 각도 숫자를 "오른팔 관절 근처"에 굵게 표시
        sx, sy = int(RSH.x*w), int(RSH.y*h)
        ex, ey = int(REL.x*w), int(REL.y*h)
        wx_, wy_ = int(RWR.x*w), int(RWR.y*h)

        # 배경 박스 + 텍스트(가독성 ↑)
        for (tx, ty, txt) in [(sx, sy, str(shoulder_angle)),
                              (ex, ey, str(elbow_angle)),
                              (wx_, wy_, str(wrist_angle))]:
            (tw, th), baseline = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)
            cv2.rectangle(frame, (tx+8, ty-10-th), (tx+8+tw+6, ty-10+baseline), (0,0,0), -1)
            cv2.putText(frame, txt, (tx+10, ty-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)

        # 포즈 전체 라인도 유지
        mp_draw.draw_landmarks(frame, pose_res.pose_landmarks, mp_pose.POSE_CONNECTIONS)

    # -----------------------------------------
    # 2) 손: 오른손(그리퍼), 왼손(회전) 시각화/계산
    # -----------------------------------------
    rotation_deg = 90        # 서보 회전에 보낼 값 (0~175)
    left_dist_show = 0.0     # 왼손 엄지-검지 거리(정규화 전/후 중 전시 용도)

    if hands_res.multi_hand_landmarks and hands_res.multi_handedness:
        for hand_lm, hand_hd in zip(hands_res.multi_hand_landmarks,
                                    hands_res.multi_handedness):
            label = hand_hd.classification[0].label  # 'Right' or 'Left'
            mp_draw.draw_landmarks(frame, hand_lm, mp_hands.HAND_CONNECTIONS)

            # 기본 포인트
            WRIST = hand_lm.landmark[0]
            TH_T  = hand_lm.landmark[4]   # THUMB_TIP
            IN_T  = hand_lm.landmark[8]   # INDEX_TIP
            # 손 크기(정규화 스케일): 손목-중지 MCP(9) 거리 사용
            MID_MCP = hand_lm.landmark[9]
            palm_size = math.dist((WRIST.x, WRIST.y), (MID_MCP.x, MID_MCP.y)) + 1e-6

            # 두 점 픽셀좌표 (표시용)
            tx, ty = int(TH_T.x*w), int(TH_T.y*h)
            ix, iy = int(IN_T.x*w), int(IN_T.y*h)

            # 핀치 거리(정규화)
            pinch = math.dist((TH_T.x, TH_T.y), (IN_T.x, IN_T.y))
            pinch_norm = pinch / palm_size

            if label == "Right":
                # ----- 오른손: 그리퍼 OPEN/CLOSE (히스테리시스 + EMA) -----
                ema_grip = pinch_norm if ema_grip is None else (ALPHA*pinch_norm + (1-ALPHA)*ema_grip)

                # 히스테리시스: 떨림 억제
                if gripper_state == "OPEN" and ema_grip < GRIP_CLOSE_T:
                    gripper_state = "CLOSE"
                elif gripper_state == "CLOSE" and ema_grip > GRIP_OPEN_T:
                    gripper_state = "OPEN"

                gripper_val = 175 if gripper_state == "CLOSE" else 5

                # 오른손은 전체 손가락 랜드마크 계속 표시 + 핀치선 & 수치도 표시
                cv2.circle(frame, (tx, ty), 7, (0,0,255), -1)
                cv2.circle(frame, (ix, iy), 7, (255,0,0), -1)
                cv2.line(frame, (tx, ty), (ix, iy), (0,200,255), 2)

                # 선 중앙에 정규화값 표시(가독성 ↑)
                cx, cy = (tx+ix)//2, (ty+iy)//2
                txt = f"Grip={ema_grip:.2f}  {gripper_state}"
                (tw, th), _ = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
                cv2.rectangle(frame, (cx-5, cy-10-th), (cx-5+tw+6, cy-10+4), (0,0,0), -1)
                cv2.putText(frame, txt, (cx-3, cy-10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)

            elif label == "Left":
                # ----- 왼손: 회전값 (핀치 정규화 → 0~175 매핑 + EMA) -----
                rotate_norm = pinch_norm
                ema_rot = rotate_norm if ema_rot is None else (ALPHA*rotate_norm + (1-ALPHA)*ema_rot)

                # 경험적 범위(0.06~0.45) → 0~175도로 매핑 (캘리브레이션 가능)
                rotation_deg = int(round(map_range(ema_rot, 0.06, 0.45, 5, 175)))
                rotation_deg = clamp(rotation_deg, 5, 175)
                left_dist_show = pinch  # 표시용(정규화 전)

                # 엄지/검지 점 + 연결선 + 큰 수치(선 중앙에)
                cv2.circle(frame, (tx, ty), 8, (0,0,255), -1)
                cv2.circle(frame, (ix, iy), 8, (255,0,0), -1)
                cv2.line(frame, (tx, ty), (ix, iy), (0,255,255), 3)

                cx, cy = (tx+ix)//2, (ty+iy)//2
                txt = f"dist={left_dist_show:.3f} | rot={rotation_deg}"
                (tw, th), _ = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
                cv2.rectangle(frame, (cx-6, cy-10-th), (cx-6+tw+8, cy-10+6), (0,0,0), -1)
                cv2.putText(frame, txt, (cx-4, cy-10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,255), 2)

    # ------------------------------
    # 3) 아두이노 전송
    # ------------------------------
    if ser and ser.is_open:
        try:
            payload = f"{shoulder_angle},{elbow_angle},{wrist_angle},{rotation_deg},{gripper_val}\n"
            ser.write(payload.encode())
        except Exception as e:
            print("⚠️ Serial write error:", e)

    # ------------------------------
    # 4) HUD(좌상단 요약)
    # ------------------------------
    cv2.putText(frame, f"Gripper: {gripper_state} ({gripper_val})", (10,30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (50,200,255), 2)
    cv2.putText(frame, f"Rotation: {rotation_deg}", (10,60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (50,200,255), 2)

    cv2.imshow("Robot Arm Control (Pose+Hands)", frame)
    key = cv2.waitKey(1) & 0xFF
    if key in (27, ord('q')):  # ESC or q
        break

cap.release()
cv2.destroyAllWindows()
if ser and ser.is_open:
    ser.close()