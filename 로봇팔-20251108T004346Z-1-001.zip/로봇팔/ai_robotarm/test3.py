import cv2
import mediapipe as mp
import math
import serial
import time

# ====== 시리얼 (없어도 실행됨) ======
ser = None
try:
    ser = serial.Serial('COM5', 9600, timeout=1)  # 포트 번호 환경에 맞게
    time.sleep(2)
    print("✅ Arduino connected")
except Exception as e:
    print("⚠️ Arduino not connected:", e)
    ser = None

# ====== MediaPipe ======
mp_pose = mp.solutions.pose
mp_hands = mp.solutions.hands
mp_draw  = mp.solutions.drawing_utils

pose  = mp_pose.Pose(min_detection_confidence=0.7, min_tracking_confidence=0.7)
hands = mp_hands.Hands(max_num_hands=2, min_detection_confidence=0.7, min_tracking_confidence=0.7)

# ====== 유틸 ======
def calculate_angle(a, b, c):
    try:
        a = (a.x, a.y); b = (b.x, b.y); c = (c.x, c.y)
        ba = (a[0]-b[0], a[1]-b[1]); bc = (c[0]-b[0], c[1]-b[1])
        denom = (math.hypot(*ba) * math.hypot(*bc)) + 1e-6
        cosang = max(min((ba[0]*bc[0] + ba[1]*bc[1]) / denom, 1.0), -1.0)
        return int(math.degrees(math.acos(cosang)))
    except:
        return 90

def clamp(v, lo, hi): return max(lo, min(hi, v))

def map_range(x, in_lo, in_hi, out_lo, out_hi):
    if in_hi == in_lo: return out_lo
    t = (x - in_lo) / (in_hi - in_lo)
    return out_lo + clamp(t, 0.0, 1.0) * (out_hi - out_lo)

# ====== 스무딩/히스테리시스 ======
ema_grip = None
ema_rot  = None
ALPHA = 0.35
GRIP_CLOSE_T = 0.22
GRIP_OPEN_T  = 0.28
gripper_state = "OPEN"
gripper_val   = 5

# ====== 카메라 ======
cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret: continue
    frame = cv2.flip(frame, 1)
    rgb   = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    h, w, _ = frame.shape

    try:
        pose_res  = pose.process(rgb)
        hands_res = hands.process(rgb)
    except Exception as e:
        print("⚠️ Inference error:", e)
        continue

    # ------------------------------
    # 1) 왼팔 각도 계산/표시
    # ------------------------------
    shoulder_angle = elbow_angle = wrist_angle = 90
    if pose_res.pose_landmarks:
        lm = pose_res.pose_landmarks.landmark
        LSH = lm[mp_pose.PoseLandmark.LEFT_SHOULDER]
        LEL = lm[mp_pose.PoseLandmark.LEFT_ELBOW]
        LWR = lm[mp_pose.PoseLandmark.LEFT_WRIST]
        LHIP= lm[mp_pose.PoseLandmark.LEFT_HIP]
        LTH = lm[mp_pose.PoseLandmark.LEFT_THUMB]

        shoulder_angle = calculate_angle(LHIP, LSH, LEL)
        elbow_angle    = calculate_angle(LSH, LEL, LWR)
        wrist_angle    = calculate_angle(LEL, LWR, LTH)

        sx, sy = int(LSH.x*w), int(LSH.y*h)
        ex, ey = int(LEL.x*w), int(LEL.y*h)
        wx_, wy_ = int(LWR.x*w), int(LWR.y*h)

        for (tx, ty, txt) in [(sx, sy, str(shoulder_angle)),
                              (ex, ey, str(elbow_angle)),
                              (wx_, wy_, str(wrist_angle))]:
            (tw, th), baseline = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)
            cv2.rectangle(frame, (tx+8, ty-10-th), (tx+8+tw+6, ty-10+baseline), (0,0,0), -1)
            cv2.putText(frame, txt, (tx+10, ty-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)

        mp_draw.draw_landmarks(frame, pose_res.pose_landmarks, mp_pose.POSE_CONNECTIONS)

    # ------------------------------
    # 2) 손 제스처 (오른손=Gripper, 왼손=회전)
    # ------------------------------
    rotation_deg = 90
    left_dist_show = 0.0

    if hands_res.multi_hand_landmarks and hands_res.multi_handedness:
        for hand_lm, hand_hd in zip(hands_res.multi_hand_landmarks,
                                    hands_res.multi_handedness):
            label = hand_hd.classification[0].label
            mp_draw.draw_landmarks(frame, hand_lm, mp_hands.HAND_CONNECTIONS)

            WRIST = hand_lm.landmark[0]
            TH_T  = hand_lm.landmark[4]
            IN_T  = hand_lm.landmark[8]
            MID_MCP = hand_lm.landmark[9]
            palm_size = math.dist((WRIST.x, WRIST.y), (MID_MCP.x, MID_MCP.y)) + 1e-6

            tx, ty = int(TH_T.x*w), int(TH_T.y*h)
            ix, iy = int(IN_T.x*w), int(IN_T.y*h)
            pinch = math.dist((TH_T.x, TH_T.y), (IN_T.x, IN_T.y))
            pinch_norm = pinch / palm_size

            if label == "Right":  # 오른손 = Gripper
                ema_grip = pinch_norm if ema_grip is None else (ALPHA*pinch_norm + (1-ALPHA)*ema_grip)
                if gripper_state == "OPEN" and ema_grip < GRIP_CLOSE_T:
                    gripper_state = "CLOSE"
                elif gripper_state == "CLOSE" and ema_grip > GRIP_OPEN_T:
                    gripper_state = "OPEN"
                gripper_val = 175 if gripper_state == "CLOSE" else 5

                cv2.circle(frame, (tx, ty), 7, (0,0,255), -1)
                cv2.circle(frame, (ix, iy), 7, (255,0,0), -1)
                cv2.line(frame, (tx, ty), (ix, iy), (0,200,255), 2)
                cx, cy = (tx+ix)//2, (ty+iy)//2
                cv2.putText(frame, f"Grip={ema_grip:.2f} {gripper_state}", (cx, cy-10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)

            elif label == "Left":  # 왼손 = 회전
                ema_rot = pinch_norm if ema_rot is None else (ALPHA*pinch_norm + (1-ALPHA)*ema_rot)
                rotation_deg = int(round(map_range(ema_rot, 0.06, 0.45, 5, 175)))
                rotation_deg = clamp(rotation_deg, 5, 175)
                left_dist_show = pinch

                cv2.circle(frame, (tx, ty), 8, (0,0,255), -1)
                cv2.circle(frame, (ix, iy), 8, (255,0,0), -1)
                cv2.line(frame, (tx, ty), (ix, iy), (0,255,255), 3)
                cx, cy = (tx+ix)//2, (ty+iy)//2
                cv2.putText(frame, f"dist={left_dist_show:.3f} | rot={rotation_deg}", (cx, cy-10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,255), 2)

    # ------------------------------
    # 3) 아두이노 전송
    # ------------------------------
    if ser and ser.is_open:
        try:
            payload = f"{shoulder_angle},{elbow_angle},{wrist_angle},{rotation_deg},{gripper_val}\n"
            ser.write(payload.encode())
        except Exception as e:
            print("⚠️ Serial write error:", e)

    # ------------------------------
    # 4) HUD
    # ------------------------------
    cv2.putText(frame, f"Gripper: {gripper_state} ({gripper_val})", (10,30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (50,200,255), 2)
    cv2.putText(frame, f"Rotation: {rotation_deg}", (10,60),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (50,200,255), 2)

    cv2.imshow("Robot Arm Control (Right=Gripper, Left=Rotation)", frame)
    key = cv2.waitKey(1) & 0xFF
    if key in (27, ord('q')):
        break

cap.release()
cv2.destroyAllWindows()
if ser and ser.is_open:
    ser.close()
